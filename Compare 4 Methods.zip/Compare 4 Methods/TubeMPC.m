%%operate tube based MPC
function [X2,U2,real_cost,s]=TubeMPC(d_all,N,iter)

nx=2;%state dimension
nu=1;%input dimension
nd=1;%disturbance dimension
len=30;%iteration numbers

x_l=[-7;-7];%lower bound
x_u=-x_l;

%negative lower bound ---upper bound
u_l=-7;
u_u=-u_l;

X_l=[kron(ones(N,1),x_l);x_l];%big Xl which includes N xl plus one xNl
X_u=[kron(ones(N,1),x_u);x_u];%big Xu which includes N xu plus one xNu

U_l=kron(ones(N,1),u_l);%big Ul which includes N ul
U_u=kron(ones(N,1),u_u);%big Uu which includes N uu



A=[1 0.8;
   0.5 1];
Bu=[1;1];
Bd=0.1*[1;1];
d_u = 1;



[P,K] = RCIset(A,Bu,Bd,x_u,u_u,d_u);

tic
z1=P\([-1;1]);
z2=P\([1;1]);% the invariant polytopic set of states

%Compute a tighter constraints for nominal state
xt_l=x_l+abs(z2);
xt_u=x_u-abs(z2);

%set the initial state for actual state on the boundary
x_real=[x_u(1);x_u(2)];

%set the initial state for nominal state on the centre of RPI
x_nominal=x_real-z2;



%%
%Norminal MPC
Q=eye(nx); R=eye(nu); 
Q_N=eye(nx);R_N=eye(nu);%terminal constraints


%%    
%Implement tube MPC for both nominal and actual state

X1=x_nominal;%initialization for nominal state
X2=x_real;%initialization for actual state

x0_p = x_nominal;
x1_p = x_real;
i=1;


%Nominal MPC
[X1,U1] = Compute_Nominal_Trajectory(A,Bu,x_l,u_l,Q,Q_N,R,R_N,x_nominal,N,iter);
U1=[U1 0];

%Create box to calculate cost at each state
nominal_cost=[];
real_cost=[];

%initialize the original state
nominal_cost=[nominal_cost;x_nominal'*Q*x_nominal];
real_cost=[real_cost;x_real'*Q*x_real+U1(:,1)'*R*U1(:,1)];

while(i <= iter)
    x_nominal=X1(:,i+1);%nominal system trajectory
    nominal_cost = [nominal_cost,x_nominal'*Q*x_nominal+U1(:,i+1)'*R*U1(:,i+1)];
    
    %implement the feedback law for actual state
    d=d_all(:,:,i); % Current disturbance
    d0=d(1:nd,1);
    U2(:,i)=U1(:,i)+K*(X2(:,i)-X1(:,i));
    X2(:,i+1)=A*X2(:,i)+Bu*U2(:,i)+ Bd*d0;
    
    x_real=X2(:,i+1);
    
    real_cost=[real_cost,x_real'*Q*x_real+U2(:,i)'*R*U2(:,i)];
    
    
    %tracking the state
    x0_p = [x0_p, x_nominal];
    x1_p = [x1_p, x_real];
    i = i + 1;
end
s=toc;


