function [x,u] = Compute_Nominal_Trajectory(A,Bu,x_l,u_l,Q,Q_N,R,R_N,x0,N,iter)

%Size of the System
nx=size(A,1);
nu=size(Bu,2);

Q=Q; R=R;

xlower=x_l;
xupper=-xlower;
x_lower=kron(ones(N,1),xlower);
x_upper=kron(ones(N,1),xupper);%trajectory constraint of states
% x_lower(1:nx)=1.5*x_lower(1:nx);
% x_upper(1:nx)=1.5*x_upper(1:nx);

ulower=u_l;
% ulower=-abs(randn(nu,1));
uupper=-ulower;

u_lower=kron(ones(N,1),ulower);
u_upper=kron(ones(N,1),uupper);%trajectory constraint of input

%x0=[6.8875;6.8201];
%x0=xlower+(xupper-xlower)*0.99;

Qbar=[kron(eye(N-1),Q),zeros((N-1)*nx,nx);zeros(nx,(N-1)*nx),Q_N];%including terminal pentalty matrix (No initial state)
Rbar=[kron(eye(N-1),R),zeros((N-1)*nu,nu);zeros(nu,(N-1)*nu),R_N];%P=Q

%Generate Phi and Gamma
[Phi, Gamma] = Coefficientgen(A, Bu, nx, nu, N);




i=1;

%Record Nominal state in each iteration
x(:,1)=x0;

while i<=iter
    H=2*(Rbar+Gamma'*Qbar*Gamma);
    H=0.5*(H+H');
    f=(2*x(:,i)'*Phi'*Qbar*Gamma)';
    Ac=[Gamma;-Gamma];
    b=[x_upper;-x_lower]+[-Phi;Phi]*x(:,i);
    U=quadprog(H,f,Ac,b,[],[],u_lower,u_upper);
    u(i)=U(1);
    x(:,i+1)=A*x(:,i)+Bu*u(i);%update new state
    i=i+1;
end

% plot(x(1,:),x(2,:),'*-r')
% hold on
% plot(x0(1),x0(2),'o')
% hold on
% grid on
% line([xlower(1,1),xlower(1,1)],[xlower(2,1),xupper(2,1)])
% line([xupper(1,1),xupper(1,1)],[xupper(2,1),xlower(2,1)])
% line([xlower(1,1),xupper(1,1)],[xlower(2,1),xlower(2,1)])
% line([xlower(1,1),xupper(1,1)],[xupper(2,1),xupper(2,1)])
% hold on
end