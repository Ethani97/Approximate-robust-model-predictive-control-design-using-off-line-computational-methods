% MATLAB code for RCI set and Inner Controller
function[P,b,K,corner,Trace_W] = RCIset(A,Bu,Bw,x_u,u_u,d)
%d is the upper bound of disturbance
Trace_W=[];
corner=[];

%parameters definition
[nx nu] = size(Bu);
[nx nw] = size(Bw);

Nx=nx;
Nu=nu;
Nn=nx;

% state and input constraints
x_bar=x_u;
u_bar=u_u;

Vx=[eye(nx)];
Vu=[eye(nu)];

% Px<=b Invariant Set boundary 
b=ones(nx,1);

cvx_begin sdp quiet
variable W_up(nx,nx) symmetric;
variable lambda(nx,nx) diagonal;
variable Xinv(nx,nx,Nn) symmetric;
variable E(nx,nx,Nn) symmetric;
variable Q(nx,nx,Nn) symmetric;
variable H(nx,nx,Nn) diagonal;
variable F(nx,nx,Nn) diagonal;
variable Z(nx,nx,Nn) diagonal;
variable P_inv(nx,nx);
variable D(nx,nx,Nx) diagonal;
variable Du(nx,nx,Nu) diagonal;
variable Dx_hat(nx,nx,Nn) diagonal;
variable Dw_hat(nw,nw,Nn) diagonal;
variable K_hat(nu,nx);

%minimize the upper bound/volume of invariant set
minimize(trace(W_up));    

subject to

lambda>=0;
W_up>=0;

[W_up     P_inv;
    P_inv'  eye(nx)]>=0; %(25)

newlab=diag(lambda);

e=eye(Nn);
for i=1:Nn  
    
    [E(:,:,i)  Z(:,:,i);
        Z(:,:,i)' Q(:,:,i)]>=0;   
    
    li=4*(newlab(i,:)*e(:,i)'*b-d'*Dw_hat(:,:,i)*d-b'*Dx_hat(:,:,i)*b); 
    
    [Q(:,:,i)-Xinv(:,:,i)        F(:,:,i)-P_inv     H(:,:,i)-P_inv       Z(:,:,i)'*e(:,i);
        (F(:,:,i)-P_inv)'           2*lambda-E(:,:,i)    lambda+F(:,:,i)'-Z(:,:,i)       zeros(nx,1);
        (H(:,:,i)-P_inv)'     (lambda+F(:,:,i)'-Z(:,:,i))'  H(:,:,i)'+H(:,:,i)-Q(:,:,i)     zeros(nx,1);
        (Z(:,:,i)'*e(:,i))'         (zeros(nx,1))'     (zeros(nx,1))'                   li]  >=0;  
    
    Dx_hat(:,:,i)>=0;
    
    [Dx_hat(:,:,i)               zeros(nx,nw)       (A*P_inv+Bu*K_hat)';
        zeros(nx,nw)'            Dw_hat(:,:,i)         Bw';
        (A*P_inv+Bu*K_hat)        Bw                Xinv(:,:,i)]>=0; 
end

ej=eye(nu);
for j=1:Nu
    Du(:,:,j)>=0;
    
    [Du(:,:,j)                      -0.5*K_hat'*Vu'*ej(:,j);
        (-0.5*K_hat'*Vu'*ej(:,j))'       ej(:,j)'*u_bar-b'*Du(:,:,j)*b]>=0;  
end


em=eye(nx);
for m=1:Nx
    D(:,:,m)>=0;
    
    [D(:,:,m)                          -0.5*(P_inv)'*Vx'*em(:,m);
        (-0.5*(P_inv)'*Vx'*em(:,m))'       em(:,m)'*x_bar-b'*D(:,:,m)*b]>=0;
end

cvx_end;

P0_inv=P_inv;
K0_hat=K_hat;

for i=1:Nn
    X0(:,:,i)=inv(Xinv(:,:,i).*newlab);
end

%update solution

iteration=10;
tol=0.01;
k=1;
W0_up=0;

while (k <= iteration) && abs((trace(W0_up)-trace(W_up))/trace(W0_up))>tol
    W0_up=W_up;
    P0_inv=P_inv;
    K0_hat=K_hat;

 for i=1:Nn
     X0(:,:,i)=inv(Xinv(:,:,i));
 end
 
 cvx_begin sdp quiet
 variable W_up(nx,nx) symmetric;
 variable lambda(nx,nx) diagonal;
 variable Xinv(nx,nx,Nn) symmetric;
 variable E(nx,nx,Nn) symmetric;
 variable Q(nx,nx,Nn) symmetric;
 variable H(nx,nx,Nn) diagonal;
 variable F(nx,nx,Nn) diagonal;
 variable Z(nx,nx,Nn) diagonal;
 variable P_inv(nx,nx);
 variable D(nx,nx,Nx) diagonal;
 variable Du(nx,nx,Nu) diagonal;
 variable Dx(nx,nx,Nn) diagonal;
 variable Dw(nw,nw,Nn) diagonal;
 variable K_hat(nu,nx);
 
 e=eye(Nn);
 
 %minimize the upper bound/volume of invariant set 
 minimize(trace(W_up));
 
 subject to
 
 lambda>=0;
 W_up>=0;
 
 newlab=diag(lambda);
 
 [W_up     P_inv;
     P_inv'   eye(nx)]>=0; 
 
 %invariance update
 for i=1:Nn     
     [E(:,:,i)  Z(:,:,i);
         Z(:,:,i)' Q(:,:,i)]>=0;
     
     l_11=P_inv'*X0(:,:,i)*P0_inv+P0_inv'*X0(:,:,i)*P_inv-P0_inv'*X0(:,:,i)*Xinv(:,:,i)*X0(:,:,i)*P0_inv; 
     
     [l_11                       e(:,i)*newlab(i,:);
         (e(:,i)*newlab(i,:))'      4*(newlab(i,:)*e(:,i)'*b-d'*Dw(:,:,i)*d-b'*Dx(:,:,i)*b)]>=0;
     
     Dx(:,:,i)>=0;
     
     [Dx(:,:,i)               zeros(nx,nw)       (A*P_inv+Bu*K_hat)';
         zeros(nx,nw)'            Dw(:,:,i)         Bw';
         (A*P_inv+Bu*K_hat)      Bw                Xinv(:,:,i)]>=0;  
 
 end
 
 
 %input constraint update
 for j=1:Nu
     Du(:,:,j)>=0;
     
     [Du(:,:,j)                      -0.5*K_hat'*Vu'*ej(:,j);
     (-0.5*K_hat'*Vu'*ej(:,j))'       ej(:,j)'*u_bar-b'*Du(:,:,j)*b]>=0;
 end
 
 em=eye(nx);
 
 %state constraint update
 for m=1:Nx
     D(:,:,m)>0;
     
     [D(:,:,m)                       -0.5*(P_inv)'*Vx'*em(:,m);
         (-0.5*P_inv'*Vx'*em(:,m))'          em(:,m)'*x_bar-b'*D(:,:,m)*b]>=0;
 
 end
 
 cvx_end;
 
k=k+1;  
P=inv(P_inv)
K=K_hat*P;


corner_point=[P\[1;1] P\[-1;1] P\[-1;-1] P\[1;-1]];
corner=[corner;corner_point];
Trace_W=[Trace_W trace(W_up)];
figure(7)
plotregion([P;-P],-[b;b],[],[],'b',0.3);hold on
axis equal
xlabel('$x_1$','interpreter','latex');
ylabel('$x_2$','interpreter','latex');
title('Update of RCI Set')
end
figure(7)
plot(0,0,'yo','MarkerFaceColor','y')
legend('RCI_1','RCI_2','RCI_3','RCI_4','RCI_5','RCI_6','RCI_7','RCI_8','Minimal RCI','Origin','interpreter','latex')
