%%operate tube based MPC
clc
clear all
close all



nx=2;%state dimension
nu=1;%input dimension
nd=1;%disturbance dimension
N=5;%horizon length
len=15;%iteration numbers


%Upper bound and lower bound for state and input
x_l=[-7;-7];%lower bound x
x_u=-x_l;%upper bound x

u_l=-7;
u_u=-u_l;

%Trajectory constraint
X_l=[kron(ones(N,1),x_l);x_l];
X_u=[kron(ones(N,1),x_u);x_u];

U_l=kron(ones(N,1),u_l);
U_u=kron(ones(N,1),u_u);


% DLTI system
A=[1 0.8;
   0.5 1];
Bu=[1;1];
Bd=0.1*[1;1];
d_u = 1;

tic
 
% find invariant set C and inner controller K  --generate tube set
[P,b,K,corner,Trace_W] = RCIset(A,Bu,Bd,x_u,u_u,d_u);

%Corner points of RCI set
z1=P\([-1;1].*b);
z2=P\([1;1].*b);

%Compute a tighter constraints for nominal state
xt_l=x_l+abs(z2);
xt_u=x_u-abs(z2);

%set the initial state for actual state on the boundary
x_real=[x_u(1);x_u(2)];

%set the initial state for nominal state on the centre of RCI set
x_nominal=x_real-z2;


%%
%Norminal MPC
Q=eye(nx); R=eye(nu); 
Q_N=eye(nx);R_N=eye(nu);%terminal constraints

Qbar=[kron(eye(N-1),Q),zeros((N-1)*nx,nx);zeros(nx,(N-1)*nx),Q_N];%including terminal pentalty matrix   do not include initial state
Rbar=kron(eye(N),R);


%%    
%Implement tube MPC for both nominal and actual state

X1=x_nominal;%initialization for nominal state
X2=x_real;%initialization for actual state

x0_p = x_nominal;
x1_p = x_real;
i=1;

%Nominal MPC
[X1,U1] = Compute_Nominal_Trajectory(A,Bu,x_l,u_l,Q,Q_N,R,R_N,x_nominal,len);
U1=[U1 0];

%Create box to calculate cost at each state
nominal_cost=[];
real_cost=[];

%initialize the original state
nominal_cost=[nominal_cost;x_nominal'*Q*x_nominal];
real_cost=[real_cost;x_real'*Q*x_real+U1(:,1)'*R*U1(:,1)];

while(i <= len)
    x_nominal=X1(:,i+1);%nominal system trajectory
    nominal_cost = [nominal_cost,x_nominal'*Q*x_nominal+U1(:,i+1)'*R*U1(:,i+1)];
    
    %implement the feedback law for actual state
    Cur_d= -ones(nd,1)*d_u+ rand.*ones(nd,1)*d_u*2; % Current disturbance
    
    D_Cur(:,i)=Cur_d;  
    U2(:,i)=U1(:,i)+K*(X2(:,i)-X1(:,i));
    X2(:,i+1)=A*X2(:,i)+Bu*U2(:,i)+ Bd*D_Cur(:,i);
    
    x_real=X2(:,i+1);
    
    real_cost=[real_cost,x_real'*Q*x_real+U2(:,i)'*R*U2(:,i)];
    
    
    %tracking the state
    x0_p = [x0_p, x_nominal];
    x1_p = [x1_p, x_real];
    i = i + 1;
end
toc


%plot the trajectory of the state for both actual and nominal
figure(1);
plot(X1(1,1),X1(2,1),'--k+');
plot(X2(1,1),X2(2,1),'--b*');
%axis([-20,20,-10,10]);
hold on;

%plot the invariant set
Z=[z1(1)+X1(1,1),z2(1)+X1(1,1),-z1(1)+X1(1,1),-z2(1)+X1(1,1),z1(1)+X1(1,1);
    z1(2)+X1(2,1),z2(2)+X1(2,1),-z1(2)+X1(2,1),-z2(2)+X1(2,1),z1(2)+X1(2,1)];
plot(Z(1,:),Z(2,:), 'k');
h0=fill(Z(1,:),Z(2,:), [0.7,0.8,1]);
set(h0,'edgealpha',0,'facealpha',0.3) 

for j=2:i
Z=[z1(1)+X1(1,j),z2(1)+X1(1,j),-z1(1)+X1(1,j),-z2(1)+X1(1,j),z1(1)+X1(1,j);
    z1(2)+X1(2,j),z2(2)+X1(2,j),-z1(2)+X1(2,j),-z2(2)+X1(2,j),z1(2)+X1(2,j)];
% Z=[z1(1)+X1(1,j),z2(1)+X1(1,j),z3(1)+X1(1,j),-z1(1)+X1(1,j),-z2(1)+X1(1,j),-z3(1)+X1(1,j),z1(1)+X1(1,j);
%     z1(2)+X1(2,j),z2(2)+X1(2,j),z3(2)+X1(1,j),-z1(2)+X1(2,j),-z2(2)+X1(2,j),-z3(2)+X1(1,j),z1(2)+X1(2,j)];
plot(Z(1,:),Z(2,:),'k');
h0=fill(Z(1,:),Z(2,:), [0.7,0.8,1]);
set(h0,'edgealpha',0,'facealpha',0.3) 
end

plot(X1(1,:) ,X1(2,:),'--ro','MarkerFaceColor','r');
plot(X2(1,:) ,X2(2,:),'--bs','MarkerFaceColor','b');

hold on;
%plot the invariant set
plotregion([P;-P],[-b;-b],[],[],'r');hold on
plot(X1(1,i),X1(2,i),'--ro','MarkerFaceColor','r');
plot(X2(1,i),X2(2,i),'--bs','MarkerFaceColor','b');
grid on

%plot the constraint set for actual state
S=[x_u(1) x_u(2); x_u(1) x_l(2); x_l(1) x_l(2); x_l(1) x_u(2);x_u(1) x_u(2)]';
plot(S(1,:) ,S(2,:),'m');

%plot the constraint set for nominal state
S=[xt_l(1),xt_l(1),xt_u(1),xt_u(1),xt_l(1);xt_l(2),xt_u(2),xt_u(2),xt_l(2),xt_l(2)];
plot(S(1,:) ,S(2,:),'r');

axis([-(x_u(1)+0.1) x_u(1)+0.1 -(x_u(2)+0.1) x_u(2)+0.1])
magnify

xlabel('$x_1$','interpreter','latex')
ylabel('$x_2$','interpreter','latex')
title('Tube-Based MPC')

%plot 3D graph for states trajectory
figure(2);
%plot the trajectory of the state for both actual and nominal
k=[];
start=5;
for j=start:i
Z=[-z1(1)+X1(1,j),-z2(1)+X1(1,j),z1(1)+X1(1,j),z2(1)+X1(1,j),-z1(1)+X1(1,j);
   -z1(2)+X1(2,j),-z2(2)+X1(2,j),z1(2)+X1(2,j),z2(2)+X1(2,j),-z1(2)+X1(2,j)];
plot3([j*ones(1,5)],Z(1,:),Z(2,:),'r')
k=[k,j];
hold on;
end
grid on;
hold on;
plot3(k,X1(1,start:i),X1(2,start:i),'-k+','linewidth',1);
plot3(k,X2(1,start:i),X2(2,start:i),'-b*','linewidth',1);
title('Tube-Based MPC');
ylabel('$x_1$','interpreter','latex')
zlabel('$x_2$','interpreter','latex')
xlabel('Number of Interation','interpreter','latex')



figure(3);
%plot the trajectory of the state for both actual and nominal 
k=[];
for j=1:i
Z=[-z1(1)+X1(1,j),-z2(1)+X1(1,j),z1(1)+X1(1,j),z2(1)+X1(1,j),-z1(1)+X1(1,j);
    -z1(2)+X1(2,j),-z2(2)+X1(2,j),z1(2)+X1(2,j),z2(2)+X1(2,j),-z1(2)+X1(2,j)];

plot3([j*ones(1,5)],Z(1,:),Z(2,:),'r')
fill3(j*ones(1,5),Z(1,:),Z(2,:), [1,1,0]);
k=[k,j];
hold on;
end
grid on;

plot3(1,X1(1,1),X1(2,1),'k+');
plot3(1,X2(1,1),X2(2,1),'r*');
hold on;

plot3(k,X1(1,:),X1(2,:),'-k+','linewidth',1);
plot3(k,X2(1,:),X2(2,:),'-r*','linewidth',1);
title('Tube-Based MPC');
ylabel('$x_1$','interpreter','latex')
zlabel('$x_2$','interpreter','latex')
xlabel('Number of Interation','interpreter','latex')



figure(4);
i = linspace(1,len,len);
plot(i,real_cost(i),'-r*',i,nominal_cost(i),'-bo');
legend('Real Cost','Nominal Cost','interpreter','latex')
xlabel('Number of Iteration','interpreter','latex')
ylabel('Cost','interpreter','latex')


figure(5);
area=[];
for i=1:size(corner,1)/2
x1=corner(2*i-1,:);
x2=corner(2*i,:);
area(i)=polyarea(x1,x2);
end
x = linspace(1,size(corner,1)/2,size(corner,1)/2);
yyaxis left
plot(x,area,'--ro','MarkerFaceColor','r','linewidth',2)
ylabel('Volume of RCI Set','interpreter','latex')
z = Trace_W;
yyaxis right
plot(x,z,'--bs','MarkerFaceColor','b','linewidth',2)
ylabel('Trace of $\overline{W}$','interpreter','latex')
legend('Volume of RCI set','Trace of $\overline{W}$','interpreter','latex')
xlabel('Iteration of RCI Set Uptate','interpreter','latex')