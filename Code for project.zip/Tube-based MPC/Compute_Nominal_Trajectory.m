function [x,u] = Compute_Nominal_Trajectory(A,Bu,x_l,u_l,Q,Q_N,R,R_N,x0,len)

%Size of the System
nx=size(A,1);
nu=size(Bu,2);


Q=Q; R=R;

N=5;%horizon length
xlower=x_l;
xupper=-xlower;
%trajectory constraint of input
x_lower=kron(ones(N,1),xlower);
x_upper=kron(ones(N,1),xupper);


ulower=u_l;
uupper=-ulower;

%trajectory constraint of input
u_lower=kron(ones(N,1),ulower);
u_upper=kron(ones(N,1),uupper);


Qbar=[kron(eye(N-1),Q),zeros((N-1)*nx,nx);zeros(nx,(N-1)*nx),Q_N];%including terminal pentalty matrix (No initial state)
Rbar=[kron(eye(N-1),R),zeros((N-1)*nu,nu);zeros(nu,(N-1)*nu),R_N];%P=Q

%Generate Phi and Gamma
[Phi, Gamma] = Coefficientgen(A, Bu, nx, nu, N);

i=1;

%Record Nominal state in each iteration
x(:,1)=x0;

while i<=len
    H=2*(Rbar+Gamma'*Qbar*Gamma);
    H=0.5*(H+H');
    f=(2*x(:,i)'*Phi'*Qbar*Gamma)';
    Ac=[Gamma;-Gamma];
    b=[x_upper;-x_lower]+[-Phi;Phi]*x(:,i);
    U=quadprog(H,f,Ac,b,[],[],u_lower,u_upper);
    u(i)=U(1);
    x(:,i+1)=A*x(:,i)+Bu*u(i);%update new state
    i=i+1;
end

end