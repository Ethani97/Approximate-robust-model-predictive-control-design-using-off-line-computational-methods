function [Phi, Gama] = Coefficientgen(A, Bu, nx, nu, N)
%Form Gamma and Phi Matrices

E=[A;zeros((N-1)*nx,nx)];
B1=kron(eye(N),Bu);
A1=eye(N*nx)-[zeros(nx,(N-1)*nx) zeros(nx);%use matrix to solve Phi and Gamma 
    kron(eye(N-1),A) zeros((N-1)*nx,nx)];

Phi =A1\E;
%Phi = [eye(nx);Phi];

Gama = A1\B1;
%Gama = [zeros(nx,N*nu);Gama];
end