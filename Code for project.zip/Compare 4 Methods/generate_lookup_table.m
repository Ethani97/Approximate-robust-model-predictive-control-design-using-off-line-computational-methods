clear all;clc;close all
 

%%===========================
%Split grid
x_u_g=[7,  7,  7,   3.5,   3.5,  3.5, -3.5, -3.5, -3.5;
       7, 3.5, -3.5,     7,   3.5, -3.5, 7,  3.5, -3.5];       % lower bound
 x_l_g=[3.5, 3.5, 3.5, -3.5, -3.5,  -3.5,   -7, -7, -7;
        3.5, -3.5, -7, 3.5,  -3.5, -7,   3.5, -3.5, -7];       % upper bound
%%==========================================================

for num_grid=1:9

% Creat the box
c0_u=x_u_g(:,num_grid);
c0_l=x_l_g(:,num_grid);

% Setting dimentions of:
% state(x), input (u),disterbunces (d), constrains (f), cost (z)
nx=2;
nu=1;nd=1;
nz=nx+nu; %cost
nf=nx+nu; %upper and lower constraints   //nf = 2*nf
N=5;%Horizon
C_0=eye(size(nx,1));

%phd case 
A=[1 0.8;
   0.5 1];
Bu=[1;1];
Bd=0.1*[1;1];


dlower=-1;dupper=-dlower;
d_lower=kron(ones(N,1),dlower);%d0 - dN-1
d_upper=kron(ones(N,1),dupper);

xlower=[-7;-7];xupper=-xlower;
x_lower=kron(ones(N+1,1),xlower);
x_upper=kron(ones(N+1,1),xupper);%including terminal constraint
x_lower(1:nx,:)= 1.5*xlower;%Gicen that the initial state is out of feasible region
x_upper(1:nx,:)= 1.5*xupper;


ulower=-7;uupper=-ulower;
u_lower=kron(ones(N,1),ulower);
u_upper=kron(ones(N,1),uupper);%including terminal constraint

flower=[xlower;ulower];fupper=-flower;% f is the total constaints including state & input constraint
f_lower=[kron(ones(N+1,1),flower)];
f_upper=[kron(ones(N+1,1),fupper)];
f_lower(1:nx,1)=1.5*xlower;
f_upper(1:nx,1)=1.5*xupper;




%Generate A_tilde and B_tilde   
A_ba = eye(N*nx)-[zeros(nx,N*nx);kron(eye(N-1),A),zeros((N-1)*nx,nx)];
E = [A;zeros((N-1)*nx,nx)];
A_tilde = A_ba\E;
%A_tilde_all =[eye(nx);A_tilde];

Bu_ba = kron(eye(N),Bu);
Bu_tilde = A_ba \ Bu_ba;
%Bu_tilde_all =[zeros(nx,N*nu);Bu_tilde];
%then stack x [x0;……;xN] = A_tilde*x0 + B_tilde* [u0;u1;……;u_N-1] +
%Bd_tilede* [d0;d1;……;d_N-1]


Bd_ba = kron(eye(N),Bd);
Bd_tilde = A_ba \Bd_ba;
Bd_tilde_all = [zeros(nx,N*nd);Bd_tilde];

%%generate Cfu_tilde and Czu_tilde
Cz = [eye(nx) ; zeros(nz-nx,nx)];
Cz_hat = Cz;
Dzu=  [zeros(nz-nu,nu) ; 0.1*eye(nu)];
Dzd=0*[0.1;0.1;0.1];


Cf= [eye(nx) ; zeros(nf-nx,nx)];
Cf_hat = Cf;% fN = Cfu_hat * xN
Dfu= [zeros(nf-nu,nu) ; eye(nu)];
Dfd=0*[0.1;0.1;0.1];
%Dfd= randn(nf,nd);


Cf_tilde=Cf; Cz_tilde=Cz;
for i=1:N-1  
    Cf_tilde=[Cf_tilde;Cf*A^i];% N*nf x nx   
    Cz_tilde=[Cz_tilde;Cz*A^i];% N*nz x nx
end
Cf_tilde=[Cf_tilde;Cf_hat*A^N];
Cz_tilde=[Cz_tilde;Cz_hat*A^N];



%Generate Dfu_tilde, Dfd_tilde, Dzu_tilde and Dzd_tilde
Dfu_tilde=kron(eye(N+1),Dfu);
Dfd_tilde=kron(eye(N+1),Dfd);
Dzu_tilde=kron(eye(N+1),Dzu);
Dzd_tilde=kron(eye(N+1),Dzd);

for i=1:N
    Dfu_tilde=Dfu_tilde+kron(diag(ones(N+1-i,1),-i),Cf*(A^(i-1))*Bu);
    Dfd_tilde=Dfd_tilde+kron(diag(ones(N+1-i,1),-i),Cf*(A^(i-1))*Bd);
    Dzu_tilde=Dzu_tilde+kron(diag(ones(N+1-i,1),-i),Cz*(A^(i-1))*Bu);
    Dzd_tilde=Dzd_tilde+kron(diag(ones(N+1-i,1),-i),Cz*(A^(i-1))*Bd);
end
Dfu_tilde = Dfu_tilde(:,1:N);
Dfd_tilde = Dfd_tilde(:,1:N);
Dzu_tilde = Dzu_tilde(:,1:N);
Dzd_tilde = Dzd_tilde(:,1:N);


%set initial state

Nx=(N+1)*nx;
Nu=(N)*nu;
Nd=(N)*nd;
Nf=(N+1)*nf;
Nz=(N+1)*nz;


Bita=[];
e=ones(Nf,1); 
%% Set K=0 and minimize bita
cvx_begin sdp
cvx_precision high
     variable bita;
     variable V_hat(N*nu,1);
     variable K0_hat(N*nu,nx);
     variable Kw_hat(N*nu,N*nx);
     variable M_low(Nf,Nf) diagonal;
     variable M_up(Nf,Nf) diagonal;
     variable mu_low;
     variable mu_up;
     variable D_0_low(nx,nx) diagonal;
     variable D_w_low(Nd,Nd) diagonal;
     variable D_0_up(nx,nx) diagonal;
     variable D_w_up(Nd,Nd) diagonal
     
     %give a fixed Khat in case infeasible and no bita
     %constraint lower bound
     
     T1_flow11 = 2*mu_low;    
     T1_flow21 = Dfu_tilde*V_hat-bita*f_lower-M_low*e-e*mu_low;
     T1_flow22 = M_low+M_low';
     T1_flow = [T1_flow11 T1_flow21';
         T1_flow21 T1_flow22];
     

     T2_flow_X0=[zeros(1,nx);Cf_tilde+Dfu_tilde*K0_hat];
     T3_flow_X0=[eye(1) zeros(1,Nf)];
     
     T2_flow_w=[zeros(1,Nd);Dfd_tilde+Dfu_tilde*Kw_hat*Bd_tilde];
     T3_flow_w=[eye(1) zeros(1,Nf)];
             
    L_11=T1_flow+T3_flow_X0'*(c0_l'*D_0_low*c0_u)*T3_flow_X0+T3_flow_w'*(d_lower'*D_w_low*d_upper)*T3_flow_w; 
    L_21=T2_flow_X0'-0.5*(C_0'*D_0_low*(c0_l+c0_u))*T3_flow_X0;
    L_31=T2_flow_w'-0.5*(D_w_low*(d_lower+d_upper))*T3_flow_w;
    L_22=C_0'*D_0_low*C_0;
    L_33=D_w_low;
    
    L_low=[L_11, L_21',L_31';
       L_21, L_22, zeros(nx,Nd);
       L_31, zeros(Nd,nx) ,L_33];
   
     %constraint upper bound
     T1_fup11 = 2*mu_up;    
     T1_fup21 = bita*f_upper-Dfu_tilde*V_hat-M_up*e-e*mu_up;
     T1_fup22 = M_up+M_up';
     T1_fup = [T1_fup11 T1_fup21';
         T1_fup21 T1_fup22];
     
     T2_fup_X0=-[zeros(1,nx);Cf_tilde+Dfu_tilde*K0_hat];
     T3_fup_X0=[eye(1) zeros(1,Nf)];
     
     T2_fup_w=-[zeros(1,Nd);Dfd_tilde+Dfu_tilde*Kw_hat*Bd_tilde];
     T3_fup_w=[eye(1) zeros(1,Nf)];
  
             
    L_11=T1_fup+T3_fup_X0'*(c0_l'*D_0_up*c0_u)*T3_fup_X0+T3_fup_w'*(d_lower'*D_w_up*d_upper)*T3_fup_w; 
    L_21=T2_fup_X0'-0.5*(C_0'*D_0_up*(c0_l+c0_u))*T3_fup_X0;
    L_31=T2_fup_w'-0.5*(D_w_up*(d_lower+d_upper))*T3_fup_w;
    L_22=C_0'*D_0_up*C_0;
    L_33=D_w_up;
    
    L_up=[L_11, L_21',L_31';
       L_21, L_22, zeros(nx,Nd);
       L_31, zeros(Nd,nx) ,L_33];
   
       
    minimize(bita);
    
    subject to
    %constraints for cost function
    L_low>=0;   
    L_up>=0;
    D_0_low>=0;
    D_0_up>=0;
    D_w_low>=0;
    D_w_up>=0;
    bita>=1;
 cvx_end;


%% Minimizing gama

clear ('K0_hat','Kw_hat','V_hat')

 cvx_begin sdp
 cvx_precision high
     variable gama; 
     variable V_hat(N*nu,1);
     variable K0_hat(N*nu,nx);
     variable Kw_hat(N*nu,N*nx);
     variable D_0(nx,nx) diagonal;
     variable D_w(Nd,Nd) diagonal;

     variable M_low(Nf,Nf) diagonal ;
     variable M_up(Nf,Nf) diagonal;
     variable mu_low;
     variable mu_up;
     variable D_0_low(nx,nx) diagonal;
     variable D_w_low(Nd,Nd) diagonal;
     variable D_0_up(nx,nx) diagonal;
     variable D_w_up(Nd,Nd) diagonal
     
    %constraint lower bound
     
    z_bar=zeros(Nz,1);
    T1_z11 = gama;
    T1_z21=  Dzu_tilde*V_hat-z_bar;%Dz_tilde(K0_hat,v_hat);
    T1_z22 = eye(Nz);
    T1_z=[T1_z11 T1_z21';
          T1_z21 T1_z22];
     

     T2_z_X0=[zeros(1,nx);Cz_tilde+Dzu_tilde*K0_hat];
     T3_z_X0=[eye(1) zeros(1,Nz)];
     
     T2_z_w=[zeros(1,Nd);Dzd_tilde+Dzu_tilde*Kw_hat*Bd_tilde];
     T3_z_w=[eye(1) zeros(1,Nz)];
             
    Lz_11=T1_z+T3_z_X0'*(c0_l'*D_0*c0_u)*T3_z_X0+T3_z_w'*(d_lower'*D_w*d_upper)*T3_z_w; 
    Lz_21=T2_z_X0'-0.5*(C_0'*D_0*(c0_l+c0_u))*T3_z_X0;
    Lz_31=T2_z_w'-0.5*(D_w*(d_lower+d_upper))*T3_z_w;
    Lz_22=C_0'*D_0*C_0;
    Lz_33=D_w;
    
    Lz=[Lz_11, Lz_21',Lz_31';
       Lz_21, Lz_22, zeros(nx,Nd);
       Lz_31, zeros(Nd,nx) ,Lz_33];
   
    %constraint lower bound
     
     T1_flow11 = 2*mu_low;    
     T1_flow21 = Dfu_tilde*V_hat-bita*f_lower-M_low*e-e*mu_low;
     T1_flow22 = M_low+M_low';
     T1_flow = [T1_flow11 T1_flow21';
         T1_flow21 T1_flow22];
     

     T2_flow_X0=[zeros(1,nx);Cf_tilde+Dfu_tilde*K0_hat];
     T3_flow_X0=[eye(1) zeros(1,Nf)];
     
     T2_flow_w=[zeros(1,Nd);Dfd_tilde+Dfu_tilde*Kw_hat*Bd_tilde];
     T3_flow_w=[eye(1) zeros(1,Nf)];
             
    L_11=T1_flow+T3_flow_X0'*(c0_l'*D_0_low*c0_u)*T3_flow_X0+T3_flow_w'*(d_lower'*D_w_low*d_upper)*T3_flow_w; 
    L_21=T2_flow_X0'-0.5*(C_0'*D_0_low*(c0_l+c0_u))*T3_flow_X0;
    L_31=T2_flow_w'-0.5*(D_w_low*(d_lower+d_upper))*T3_flow_w;
    L_22=C_0'*D_0_low*C_0;
    L_33=D_w_low;
    
    L_low=[L_11, L_21',L_31';
       L_21, L_22, zeros(nx,Nd);
       L_31, zeros(Nd,nx) ,L_33];
   
     %constraint upper bound
     T1_fup11 = 2*mu_up;    
     T1_fup21 = bita*f_upper-Dfu_tilde*V_hat-M_up*e-e*mu_up;
     T1_fup22 = M_up+M_up';
     T1_fup = [T1_fup11 T1_fup21';
         T1_fup21 T1_fup22];
     
     T2_fup_X0=-[zeros(1,nx);Cf_tilde+Dfu_tilde*K0_hat];
     T3_fup_X0=[eye(1) zeros(1,Nf)];
     
     T2_fup_w=-[zeros(1,Nd);Dfd_tilde+Dfu_tilde*Kw_hat*Bd_tilde];
     T3_fup_w=[eye(1) zeros(1,Nf)];
  
             
    L_11=T1_fup+T3_fup_X0'*(c0_l'*D_0_up*c0_u)*T3_fup_X0+T3_fup_w'*(d_lower'*D_w_up*d_upper)*T3_fup_w; 
    L_21=T2_fup_X0'-0.5*(C_0'*D_0_up*(c0_l+c0_u))*T3_fup_X0;
    L_31=T2_fup_w'-0.5*(D_w_up*(d_lower+d_upper))*T3_fup_w;
    L_22=C_0'*D_0_up*C_0;
    L_33=D_w_up;
    
    L_up=[L_11, L_21',L_31';
       L_21, L_22, zeros(nx,Nd);
       L_31, zeros(Nd,nx) ,L_33];
   
    minimize(gama);
    subject to
    %constraints for cost function
    Lz>=0;   
    D_w>=0;
    D_0>=0;
    
    L_low>=0;   
    L_up>=0;
    D_0_low>=0;
    D_0_up>=0;
    D_w_low>=0;
    D_w_up>=0;
 cvx_end;

%causality--sometimes infeasible
% for i=1:N
%     Kw_hat(i,((i-1)*nx+1):(N)*nx)=0;
% end

Khat =inv(eye(Nu)+Kw_hat*Bu_tilde)*Kw_hat;
    
% Greate a structure that save all the information for a certain grid
field1 = 'up_bound';      value1 = c0_u;
field2 = 'low_bound';     value2 = c0_l;
field3 = 'Kw_hat';         value3 = Kw_hat;
field4 = 'Khat';          value4 = Khat;
field5 = 'bita';          value5 = bita;
grids(num_grid) = struct(field1,value1,field2,value2,field3,value3,field4,value4,field5,value5);
end

save('gridsNew','grids');







