clear all
clc
close all

%Before comparing, generate off-line table with according N first
%#generate_lookup_table.m
nd=1;N=5;iter=15;

dlower=-1;dupper=-dlower;
d_lower=kron(ones(N,1),dlower);
d_upper=kron(ones(N,1),dupper);

for k=1:iter
d_all(:,:,k)=d_lower+(d_upper-d_lower).*rand(N*nd,1);
end

disp('Loading Function CRMPC...');
[CPU_time_CRMPC,x_CRMPC,U_CRMPC,gam_CRMPC,J_CRMPC,s_CRMPC]=CRMPC(d_all,N,iter);
disp('Loading Function CRMPC_Singgle_LMI...');
[CPU_time_CRMPC_S,x_CRMPC_S,U_CRMPC_S,gam_CRMPC_S,J_CRMPC_S,s_CRMPC_S]=CRMPC_S(d_all,N,iter);
disp('Loading Function CRMPC_Look_up_table...');
[CPU_time_CRMPC_L,x_CRMPC_K,U_CRMPC_L,gam_CRMPC_L,J_CRMPC_L,s_CRMPC_L]=lookup_table(d_all,N,iter);
disp('Loading Function Tube-based MPC...');
[x_TBMPC,U_TBMPC,J_TBMPC,s_TBMPC]=TubeMPC(d_all,N,iter);




figure(1)
plot(x_CRMPC(1,:),x_CRMPC(2,:),'*-r');hold on
plot(x_CRMPC_S(1,:),x_CRMPC_S(2,:),'o-b');hold on
plot(x_CRMPC_K(1,:),x_CRMPC_K(2,:),'d-k');hold on
plot(x_TBMPC(1,:),x_TBMPC(2,:),'s-g')
grid on
magnify
xlower=[-7;-7];xupper=-xlower;
line([xlower(1,1),xlower(1,1)],[xlower(2,1),xupper(2,1)])
line([xupper(1,1),xupper(1,1)],[xupper(2,1),xlower(2,1)])
line([xlower(1,1),xupper(1,1)],[xlower(2,1),xlower(2,1)])
line([xlower(1,1),xupper(1,1)],[xupper(2,1),xupper(2,1)])
hold on
xlabel('$x_1$','interpreter','latex')
ylabel('$x_2$','interpreter','latex')
legend('$CRMPC$','$CRMPC_S$','$CRMPC_L$','$TBMPC$','interpreter','latex')


figure(2)
plot(J_CRMPC,'*-r');hold on
plot(J_CRMPC_S,'*-b');hold on
plot(J_CRMPC_L,'*-k');hold on
plot(J_TBMPC,'*-g');hold on
magnify
legend('Actual cost of CRMPC','Actual cost of CRMPC_S','Actual cost of CRMPC_L','Actual cost of TBMPC')
xlabel('Number of Iteration')
ylabel('Cost')

figure(3)
plot(CPU_time_CRMPC,'*-r');hold on
plot(CPU_time_CRMPC_S,'o-b');hold on 
plot(CPU_time_CRMPC_L,'d-k')
xlabel('Number of Iteration')
ylabel('CPU Time')
legend('CRMPC','CRMPC_S','CRMPC_L')
title('CPU Time')

figure(4)
plot(U_CRMPC,'*-r');hold on
plot(U_CRMPC_S,'o-b');hold on
plot(U_CRMPC_L,'d-k');hold on
plot(U_TBMPC,'s-g');hold on
plot(-7*ones(iter,1),'k-*');hold on
plot(7*ones(iter,1),'c-*');hold on
xlabel('Number of Iteration')
ylabel('Input Signal U')
legend('Input Signal U of CRMPC','Input signal U of CRMPC_S','Input Signal U of CRMPC_L','Input Signal U of TBMPC')
axis([1 iter -10 10])

figure(5)
name = categorical({'CRMPC','CRMPC_S','CRMPC_L','TBMPC'});
name = reordercats(name,{'CRMPC','CRMPC_S','CRMPC_L','TBMPC'});
s = [s_CRMPC,s_CRMPC_S,s_CRMPC_L,s_TBMPC];
bar(name,s)
title('Online Computation Time')


%data analysis
CPU_time_CRMPC=CPU_time_CRMPC(2:iter);%omit first iterm
CPU_time_CRMPC_S=CPU_time_CRMPC_S(2:iter);
CPU_time_CRMPC_L = CPU_time_CRMPC_L(2:iter);


mean_cputime=mean(CPU_time_CRMPC);
std_cputime=std(CPU_time_CRMPC);
max_cputime=max(CPU_time_CRMPC);

mean_cputime_S=mean(CPU_time_CRMPC_S);
std_cputime_S=std(CPU_time_CRMPC_S);
max_cputime_S=max(CPU_time_CRMPC_S);


%total_cputime = sum(CPU_time)
mean_cputime_lookup = mean(CPU_time_CRMPC_L);
std_cputime_lookup = std(CPU_time_CRMPC_L);
max_cputime_lookup = max(CPU_time_CRMPC_L);

figure(6)
name = categorical({'CRMPC','CRMPC_S','CRMPC_L'});
name = reordercats(name,{'CRMPC','CRMPC_S','CRMPC_L'});
mean_s = [mean_cputime,mean_cputime_S,mean_cputime_lookup];
bar(name,mean_s)
title('Mean CPU Time')