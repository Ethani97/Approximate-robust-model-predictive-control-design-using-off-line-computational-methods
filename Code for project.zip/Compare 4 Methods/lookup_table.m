function [CPU_time,x,U,gam,J,s]=lookup_table(d_all,N,iter)
nx=2;
nu=1;nd=1;
nz=nx+nu; 
nf=nx+nu; 


%case study
A=[1 0.8;
   0.5 1];
Bu=[1;1];
Bd=0.1*[1;1];


dlower=-1;dupper=-dlower;
d_lower=kron(ones(N,1),dlower);
d_upper=kron(ones(N,1),dupper);

xlower=[-7;-7];xupper=-xlower;
x_lower=kron(ones(N+1,1),xlower);
x_upper=kron(ones(N+1,1),xupper);%including terminal constraint




ulower=-7;uupper=-ulower;
u_lower=kron(ones(N,1),ulower);
u_upper=kron(ones(N,1),uupper);%including terminal constraint

flower=[xlower;ulower];fupper=-flower;% f is the total constaints including state & input constraint
f_lower=[kron(ones(N+1,1),flower)];
f_upper=[kron(ones(N+1,1),fupper)];
f_lower(1:nx,1)=1.5*xlower;
f_upper(1:nx,1)=1.5*xupper;

%Generate A_tilde and B_tilde   
A_ba = eye(N*nx)-[zeros(nx,N*nx);kron(eye(N-1),A),zeros((N-1)*nx,nx)];
E = [A;zeros((N-1)*nx,nx)];
A_tilde = A_ba\E;
%A_tilde_all =[eye(nx);A_tilde];

Bu_ba = kron(eye(N),Bu);
Bu_tilde = A_ba \ Bu_ba;
%Bu_tilde_all =[zeros(nx,N*nu);Bu_tilde];
%then stack x [x0;……;xN] = A_tilde*x0 + B_tilde* [u0;u1;……;u_N-1] +
%Bd_tilede* [d0;d1;……;d_N-1]


Bd_ba = kron(eye(N),Bd);
Bd_tilde = A_ba \Bd_ba;
Bd_tilde_all = [zeros(nx,N*nd);Bd_tilde];

%%generate Cfu_tilde and Czu_tilde
Cz = [eye(nx) ; zeros(nz-nx,nx)];
Cz_hat = Cz;
Dzu=  [zeros(nz-nu,nu) ; eye(nu)];
Dzd=0*[0.1;0.1;0.1];

Cf= [eye(nx) ; zeros(nf-nx,nx)];
Cf_hat = Cf;% fN = Cfu_hat * xN
Dfu= [zeros(nf-nu,nu) ; eye(nu)];
Dfd=0*[0.1;0.1;0.1];
%Dfd= randn(nf,nd);


Cf_tilde=Cf; Cz_tilde=Cz;
for i=1:N-1  
    Cf_tilde=[Cf_tilde;Cf*A^i];% N*nf x nx 
    Cz_tilde=[Cz_tilde;Cz*A^i];% N*nz x nx
end
Cf_tilde=[Cf_tilde;Cf_hat*A^N];
Cz_tilde=[Cz_tilde;Cz_hat*A^N];



%Generate Dfu_tilde, Dfd_tilde, Dzu_tilde and Dzd_tilde
Dfu_tilde=kron(eye(N+1),Dfu);
Dfd_tilde=kron(eye(N+1),Dfd);
Dzu_tilde=kron(eye(N+1),Dzu);
Dzd_tilde=kron(eye(N+1),Dzd);

for i=1:N
    Dfu_tilde=Dfu_tilde+kron(diag(ones(N+1-i,1),-i),Cf*(A^(i-1))*Bu);
    Dfd_tilde=Dfd_tilde+kron(diag(ones(N+1-i,1),-i),Cf*(A^(i-1))*Bd);
    Dzu_tilde=Dzu_tilde+kron(diag(ones(N+1-i,1),-i),Cz*(A^(i-1))*Bu);
    Dzd_tilde=Dzd_tilde+kron(diag(ones(N+1-i,1),-i),Cz*(A^(i-1))*Bd);
end

Dfu_tilde = Dfu_tilde(:,1:N);
Dfd_tilde = Dfd_tilde(:,1:N);
Dzu_tilde = Dzu_tilde(:,1:N);
Dzd_tilde = Dzd_tilde(:,1:N);


%set initial state
x0=xupper;
x(:,1)=x0;
Nx=(N+1)*nx;
Nu=(N)*nu;
Nd=(N)*nd;
Nf=(N+1)*nf;
Nz=(N+1)*nz;
CPU_time=[];


%gridsNew=generate_lookup_table();
load('gridsNew.mat', 'grids');

%%

% Chech in which grid is the initial state 
tic
k=1;
while k<=iter

   
       
   for i=1:9
      if ((x0<=grids(i).up_bound) & (x0>=grids(i).low_bound))
            Kw_hat=grids(i).Kw_hat;
            
            grids(i).bita;
            i;
            grid_not_found=0;
            break
      end
       grid_not_found=1;
   end

    if grid_not_found==1
    Kw_hat=zeros(N*nu,N*nx);
    end
    %i
    

    cvx_begin sdp quiet
    cvx_precision high
    variable gammaa
    variable u(N*nu,1)
    variable mu_low
    variable mu_up
    variable V_hat(N*nu,1)
    variable K0_hat(N*nu,nx)
    variable M_low(Nf,Nf) diagonal 
    variable M_up(Nf,Nf) diagonal 
    variable Di2(Nd,Nd) diagonal 
    variable Di22(Nd,Nd) diagonal 
    variable D(Nd,Nd) diagonal 
         
    %z-LMI variables
    z_bar=zeros(Nz,1);
    T1_z11 = gammaa;
    T1_z21=(Cz_tilde+Dzu_tilde*K0_hat)*x0 + Dzu_tilde*V_hat-z_bar;%Dz_tilde(K0_hat,v_hat);
    T1_z22 = eye(Nz);
    T1_z=[T1_z11 T1_z21';
          T1_z21 T1_z22];
    
    T2_z21=(Dzu_tilde*Kw_hat*Bd_tilde+Dzd_tilde);%Dzw_tile(Kw_hat)
    T2_z=[zeros(1,N*nd);T2_z21];
    
    T3_z=[eye(1) zeros(1,(N+1)*nz)];
    
    

    
    Lz = [T1_z+T3_z'*d_lower'*D*d_upper*T3_z  , T2_z-T3_z'*(d_upper+d_lower)'*D;
        (T2_z-T3_z'*(d_upper+d_lower)'*D)'  ,  D];
    

    %f-lower LMI
    e=ones(Nf,1);
    T1_flow11 = 2*mu_low;
    T1_flow21 = (Cf_tilde+Dfu_tilde*K0_hat)*x0+Dfu_tilde*V_hat-f_lower-M_low*e-e*mu_low;
    T1_flow22 = M_low+M_low';
    T1_flow = [T1_flow11 T1_flow21';
        T1_flow21 T1_flow22];
    
    T2_flow11 = zeros(1,Nd);
    T2_flow21 = Dfu_tilde*Kw_hat*Bd_tilde+Dfd_tilde;
    T2_flow = [T2_flow11;T2_flow21];
    
    T3_flow = [eye(1) zeros(1,Nf)];
    
    L_flow=[T1_flow+(d_lower*T3_flow)'*Di2*d_upper*T3_flow,   ( T2_flow'-Di2*(d_upper+d_lower)*T3_flow )';
            T2_flow'-Di2*(d_upper+d_lower)*T3_flow  ,   Di2];
    
    
    %f-upper LMI
    T1_fup11 = 2*mu_up;
    T1_fup21 = f_upper-((Cf_tilde+Dfu_tilde*K0_hat)*x0+Dfu_tilde*V_hat)-M_up*e-e*mu_up;
    T1_fup22 = M_up+M_up';
    T1_fup = [T1_fup11 T1_fup21';
        T1_fup21 T1_fup22];
    
    T2_fup11 = zeros(1,Nd);
    T2_fup21 = Dfu_tilde*Kw_hat*Bd_tilde+Dfd_tilde;T2_fup21 = -T2_fup21;
    T2_fup = [T2_fup11;T2_fup21];
    
    T3_fup = [eye(1) zeros(1,Nf)];
    
    L_fup=[T1_fup+(d_lower*T3_fup)'*Di22*d_upper*T3_fup,   ( T2_fup'-Di22*(d_upper+d_lower)*T3_fup )';
            T2_fup'-Di22*(d_upper+d_lower)*T3_fup  ,   Di22];
    
    
    minimize(gammaa)
    subject to
    D>=0;
    Di2>=0;
    Di22>=0;
    Lz>=0;
    L_flow>=0;
    L_fup>=0;
    
    cvx_end;
    
        if ~strcmp(cvx_status,'Solved')
            fprintf('\n **The problem was infeasible** \n')
            return
        end 
    
    CPU_time=[CPU_time,cvx_cputime];
    
         
        d=d_all(:,:,k);
        u=K0_hat*x0+Kw_hat*Bd_tilde*d+V_hat;
        U(:,k)=u(1:nu,1);
        d0=d(1:nd,1);

        
        z(:,k)=Cz*x(:,k)+Dzu*U(:,k)+Dzd*d0;
        J(:,k)=z(:,k)'*z(:,k);
        gam(:,k)=gammaa;
        
        
        x(:,k+1)=A*x(:,k)+Bu*U(:,k)+Bd*d0;
        
        x0=x(:,k+1);
        k=k+1;
        
end
s=toc;
end
