clear all
clc
close all

nx=2;
nu=1;nd=1;
nz=nx+nu; %cost
nf=nx+nu; %upper and lower constraints   //nf = 2*nf
N=5;

%phd case 
A=[1 0.8;
   0.5 1];
Bu=[1;1];
Bd = 0.1*[1;1];


dlower=-1;dupper=-dlower;
d_lower=kron(ones(N,1),dlower);%d0 - dN-1
d_upper=kron(ones(N,1),dupper);

xlower=[-7;-7];xupper=-xlower;
x_lower=kron(ones(N+1,1),xlower);
x_upper=kron(ones(N+1,1),xupper);%including terminal constraint
x_lower(1:nx,:)= 1.5*xlower;
x_upper(1:nx,:)= 1.5*xupper;%soft constraints -- incase initial state not in the box

ulower=-7;uupper=-ulower;
u_lower=kron(ones(N,1),ulower);
u_upper=kron(ones(N,1),uupper);%including terminal constraint

flower=[xlower;ulower];fupper=-flower;% f is the total constaints including state & input constraint
f_lower=[kron(ones(N+1,1),flower)];
f_upper=[kron(ones(N+1,1),fupper)];
f_lower(1:nx,1)=1.5*xlower;
f_upper(1:nx,1)=1.5*xupper;


%Generate A_tilde and B_tilde   
A_ba = eye(N*nx)-[zeros(nx,N*nx);kron(eye(N-1),A),zeros((N-1)*nx,nx)];
E = [A;zeros((N-1)*nx,nx)];
A_tilde = A_ba\E;
%A_tilde_all =[eye(nx);A_tilde];

Bu_ba = kron(eye(N),Bu);
Bu_tilde = A_ba \ Bu_ba;
%Bu_tilde_all =[zeros(nx,N*nu);Bu_tilde];
%then stack x [x0;……;xN] = A_tilde*x0 + B_tilde* [u0;u1;……;u_N-1] +
%Bd_tilede* [d0;d1;……;d_N-1]


Bd_ba = kron(eye(N),Bd);
Bd_tilde = A_ba \Bd_ba;
Bd_tilde_all = [zeros(nx,N*nd);Bd_tilde];

%%generate Cfu_tilde and Czu_tilde
Cz = [eye(nx) ; zeros(nz-nx,nx)];
Cz_hat = Cz;
Dzu=  [zeros(nz-nu,nu) ; 0.1*eye(nu)];
Dzd=0*[0.1;0.1;0.1];
%Dzd= randn(nz,nd);%为什么用randn呢？正态分布有什么作用

Cf= [eye(nx) ; zeros(nf-nx,nx)];
Cf_hat = Cf;% fN = Cfu_hat * xN
Dfu= [zeros(nf-nu,nu) ; eye(nu)];
Dfd=0*[0.1;0.1;0.1];
%Dfd= randn(nf,nd);


Cf_tilde=Cf; Cz_tilde=Cz;
for i=1:N-1  
    Cf_tilde=[Cf_tilde;Cf*A^i];% N*nf x nx   (若考虑初始状态则加nx)
    Cz_tilde=[Cz_tilde;Cz*A^i];% N*nz x nx
end
Cf_tilde=[Cf_tilde;Cf_hat*A^N];
Cz_tilde=[Cz_tilde;Cz_hat*A^N];



%Generate Dfu_tilde, Dfd_tilde, Dzu_tilde and Dzd_tilde
Dfu_tilde=kron(eye(N+1),Dfu);
Dfd_tilde=kron(eye(N+1),Dfd);
Dzu_tilde=kron(eye(N+1),Dzu);
Dzd_tilde=kron(eye(N+1),Dzd);

for i=1:N
    Dfu_tilde=Dfu_tilde+kron(diag(ones(N+1-i,1),-i),Cf*(A^(i-1))*Bu);%diag(ones(N+1-i,1),-i)为主对角线平移（上下）
    Dfd_tilde=Dfd_tilde+kron(diag(ones(N+1-i,1),-i),Cf*(A^(i-1))*Bd);
    Dzu_tilde=Dzu_tilde+kron(diag(ones(N+1-i,1),-i),Cz*(A^(i-1))*Bu);
    Dzd_tilde=Dzd_tilde+kron(diag(ones(N+1-i,1),-i),Cz*(A^(i-1))*Bd);
end
Dfu_tilde = Dfu_tilde(:,1:N);
Dfd_tilde = Dfd_tilde(:,1:N);
Dzu_tilde = Dzu_tilde(:,1:N);
Dzd_tilde = Dzd_tilde(:,1:N);


%set initial state
x0=0.99*xupper; 
x(:,1)=x0;
Nx=(N+1)*nx;
Nu=(N)*nu;
Nd=(N)*nd;
Nf=(N+1)*nf;
Nz=(N+1)*nz;
CPU_time=[];


tic

k=1;
iter=15; %total iterations
while k<=iter
   
    cvx_begin sdp
    cvx_precision high
    variable gammaa
    variable u(N*nu,1)
    variable mu_low
    variable mu_up
    variable V_hat(N*nu,1)
    variable K0_hat(N*nu,nx)
    variable Kw_hat(N*nu,N*nx)
    variable M_low(Nf,Nf) diagonal semidefinite
    variable M_up(Nf,Nf) diagonal semidefinite
    variable Di2(Nd,Nd) diagonal semidefinite
    variable Di22(Nd,Nd) diagonal semidefinite
    variable D(Nd,Nd) diagonal semidefinite 
         
    %z-LMI variables
    z_bar=zeros(Nz,1);
    T1_z11 = gammaa;
    T1_z21=(Cz_tilde+Dzu_tilde*K0_hat)*x0 + Dzu_tilde*V_hat-z_bar;%Dz_tilde(K0_hat,v_hat);
    T1_z22 = eye(Nz);
    T1_z=[T1_z11 T1_z21';
          T1_z21 T1_z22];
    
    T2_z21=(Dzu_tilde*Kw_hat*Bd_tilde+Dzd_tilde);%Dzw_tile(Kw_hat)
    T2_z=[zeros(1,N*nd);T2_z21];
    
    T3_z=[eye(1) zeros(1,(N+1)*nz)];
    
    
    minimize(gammaa)
    subject to
   
    D>=0;
    
    [T1_z+T3_z'*d_lower'*D*d_upper*T3_z  , T2_z-T3_z'*(d_upper+d_lower)'*D;
        (T2_z-T3_z'*(d_upper+d_lower)'*D)'  ,  D]>=0;
    

    %f-lower LMI
    e=ones(Nf,1);
    T1_flow11 = 2*mu_low;
    T1_flow21 = (Cf_tilde+Dfu_tilde*K0_hat)*x0+Dfu_tilde*V_hat-f_lower-M_low*e-e*mu_low;
    T1_flow22 = M_low+M_low';
    T1_flow = [T1_flow11 T1_flow21';
        T1_flow21 T1_flow22];
    
    T2_flow11 = zeros(1,Nd);
    T2_flow21 = Dfu_tilde*Kw_hat*Bd_tilde+Dfd_tilde;
    T2_flow = [T2_flow11;T2_flow21];
    
    T3_flow = [eye(1) zeros(1,Nf)];
    
    [T1_flow+(d_lower*T3_flow)'*Di2*d_upper*T3_flow,   ( T2_flow'-Di2*(d_upper+d_lower)*T3_flow )';
            T2_flow'-Di2*(d_upper+d_lower)*T3_flow  ,   Di2]>=0;
    
    
    %f-upper LMI
    T1_fup11 = 2*mu_up;
    T1_fup21 = f_upper-((Cf_tilde+Dfu_tilde*K0_hat)*x0+Dfu_tilde*V_hat)-M_up*e-e*mu_up;
    T1_fup22 = M_up+M_up';
    T1_fup = [T1_fup11 T1_fup21';
        T1_fup21 T1_fup22];
    
    T2_fup11 = zeros(1,Nd);
    T2_fup21 = Dfu_tilde*Kw_hat*Bd_tilde+Dfd_tilde;T2_fup21 = -T2_fup21;
    T2_fup = [T2_fup11;T2_fup21];
    
    T3_fup = [eye(1) zeros(1,Nf)];
    
    [T1_fup+(d_lower*T3_fup)'*Di22*d_upper*T3_fup,   ( T2_fup'-Di22*(d_upper+d_lower)*T3_fup )';
            T2_fup'-Di22*(d_upper+d_lower)*T3_fup  ,   Di22]>=0;
    
    
    cvx_end;
    
    CPU_time=[CPU_time,cvx_cputime];
    
    for i=1:N
        Kw_hat(1:i*nu,(i-1)*nx+1:i*nx)=zeros(i*nu,nx);
    end
    %record the state and input & update the next state 
    if norm(1)<10e5
        d(:,:,k)=d_lower+(d_upper-d_lower).*rand(N*nd,1);
        u=K0_hat*x0+Kw_hat*Bd_tilde*d(:,:,k)+V_hat;
        U(:,k)=u(1:nu,1);
        d0=d(1:nd,1,k);

        
        z(:,k)=Cz*x(:,k)+Dzu*U(:,k)+Dzd*d0;
        J(:,k)=z(:,k)'*z(:,k);
        gam(:,k)=gammaa;
        
        x(:,k+1)=A*x(:,k)+Bu*U(:,k)+Bd*d0;
        
        x0=x(:,k+1);
        k=k+1;
        
    end
end

figure(1)
plot(x(1,:),x(2,:),'*-r');hold on
grid on
line([xlower(1,1),xlower(1,1)],[xlower(2,1),xupper(2,1)])
line([xupper(1,1),xupper(1,1)],[xupper(2,1),xlower(2,1)])
line([xlower(1,1),xupper(1,1)],[xlower(2,1),xlower(2,1)])
line([xlower(1,1),xupper(1,1)],[xupper(2,1),xupper(2,1)])
hold on
xlabel('$x_1$','interpreter','latex')
ylabel('$x_2$','interpreter','latex')
legend('Trajectory of NMPC')

figure(2)
plot(J,'*-r');
hold on
plot(gam,'o-b');
hold on
legend('Actual cost J','Upper bound Gamma')
hold on
xlim([1 iter])
xlabel('Number of Iteration')
ylabel('Cost')

figure(3)
plot(CPU_time,'o-b');
legend('CPU time of cvx toolbox')
xlabel('number of iteration')
ylabel('CPU time')
hold on 

figure(4)
plot(U,'*-r');hold on
plot(uupper*ones(iter,1),'c-*');hold on
plot(ulower*ones(iter,1),'k-*');hold on
xlim([1 iter])
legend('Input Signal U','Upper bound of U','Lower bound of U')
xlabel('Number of Iteration')
ylabel('Input Signal U')
hold on

%recover the K0_tilde K_tilde and V_tilde
% Kw_hat
% K0_tilde = inv(eye(N*nu)+Kw_hat*Bu_tilde)*(K0_hat-Kw_hat*A_tilde);
% K_tilde = inv(eye(N*nu)+Kw_hat*Bu_tilde)*Kw_hat
% V_tilde = inv(eye(N*nu)+Kw_hat*Bu_tilde)*V_hat;