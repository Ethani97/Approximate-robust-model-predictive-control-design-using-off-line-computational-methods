clear all
clc
close all

%% System Formulation
%Size of the System
nx=2;
nu=1;

%Generate random system
A = [1 1;0 1];
Bu = [0.5;1];

N=5;%horizon length

%% Constraints
xlower=-[3;3];
xupper=-xlower;
x_lower=kron(ones(N,1),xlower);
x_upper=kron(ones(N,1),xupper);%trajectory constraint of states

ulower=-1;
uupper=-ulower;
u_lower=kron(ones(N,1),ulower);
u_upper=kron(ones(N,1),uupper);%trajectory constraint of input

%initial state
x0=xlower+(xupper-xlower).*0.99;
x0=x0.*[-1;1];

%% Cost function
%penalty matrices
Q=eye(nx);Q=Q*Q';%positive definite
Q_N=Q;          %terminal state penalty
 
R=0.1*eye(nu);R=R*R';%positive definite
R_N=R;          %terminal input penalty

Qbar=[kron(eye(N-1),Q),zeros((N-1)*nx,nx);zeros(nx,(N-1)*nx),Q_N];%including terminal pentalty matrix (No initial state)
Rbar=[kron(eye(N-1),R),zeros((N-1)*nu,nu);zeros(nu,(N-1)*nu),R_N];%P=Q

%Generate Phi and Gamma
[Phi, Gamma] = Coefficientgen(A, Bu, nx, nu, N);



%% Online Nominal MPC
i=1;

%Record Nominal state in each iteration
x(:,1)=x0;

while i<=20
    H=(Rbar+Gamma'*Qbar*Gamma);
    H=0.5*(H+H');
    f=Gamma'*Qbar*Phi*x(:,i);
    Ac=[Gamma;-Gamma];
    b=[x_upper;-x_lower]+[-Phi;Phi]*x(:,i);
    U=quadprog(H,f,Ac,b,[],[],u_lower,u_upper);
    u(i)=U(1);
    x(:,i+1)=A*x(:,i)+Bu*u(i);%update new state
    i=i+1;
end

plot(x(1,:),x(2,:),'*-r')
hold on
plot(x0(1),x0(2),'o')
hold on
grid on
line([xlower(1,1),xlower(1,1)],[xlower(2,1),xupper(2,1)])
line([xupper(1,1),xupper(1,1)],[xupper(2,1),xlower(2,1)])
line([xlower(1,1),xupper(1,1)],[xlower(2,1),xlower(2,1)])
line([xlower(1,1),xupper(1,1)],[xupper(2,1),xupper(2,1)])
hold on
